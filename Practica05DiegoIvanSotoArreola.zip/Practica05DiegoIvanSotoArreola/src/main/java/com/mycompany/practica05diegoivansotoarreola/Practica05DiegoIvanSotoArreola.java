package com.mycompany.practica05diegoivansotoarreola;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Polygon;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Practica05DiegoIvanSotoArreola extends JPanel implements Runnable {

    private Image fondo;

    public Practica05DiegoIvanSotoArreola() {
        try {
            // Cargar la imagen de fondo
            BufferedImage imagenOriginal = ImageIO.read(new File("C:/Users/Soto/OneDrive/Documents/NetBeansProjects/Practica05DiegoIvanSotoArreola/src/main/java/com/mycompany/practica05diegoivansotoarreola/reloj.jpg"));

            // Redimensionar la imagen a 800x600
            fondo = imagenOriginal.getScaledInstance(800, 600, Image.SCALE_SMOOTH);

            // Configurar el tamaño preferido del panel
            setPreferredSize(new Dimension(1280, 720));
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("No se pudo cargar la imagen de fondo.");
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        g2.drawImage(fondo, 0, 0, getWidth(), getHeight(), this);

        int cx = getWidth() / 2;
        int cy = getHeight() / 2;
        int radio = 200;

        GradientPaint gp = new GradientPaint(cx - radio, cy - radio, Color.LIGHT_GRAY, cx + radio, cy + radio, Color.DARK_GRAY);
        g2.setPaint(gp);
        g2.fillOval(cx - radio, cy - radio, radio * 2, radio * 2);

        dibujarNumeros(g2, cx, cy, radio);

        dibujarManecillas(g2, cx, cy, radio);
    }

    private void dibujarNumeros(Graphics2D g2, int cx, int cy, int radio) {
        g2.setColor(Color.BLACK);
        g2.setFont(new Font("Serif", Font.BOLD, 24));

        for (int i = 1; i <= 12; i++) {
            String numero = String.valueOf(i);
            double angulo = Math.toRadians(i * 30 - 90); // ángulo para cada número
            int x = (int) (cx + (radio - 30) * Math.cos(angulo));
            int y = (int) (cy + (radio - 30) * Math.sin(angulo));

            g2.drawString(numero, x - g2.getFontMetrics().stringWidth(numero) / 2, y + g2.getFontMetrics().getAscent() / 2);
        }
    }

    private void dibujarManecillaConFlecha(Graphics2D g2, int cx, int cy, double anguloGrados, int largo, int grosor, Color color) {
        double angulo = Math.toRadians(anguloGrados - 90);

        g2.setStroke(new BasicStroke(grosor));
        g2.setColor(color);

        int xFinal = (int) (cx + largo * Math.cos(angulo));
        int yFinal = (int) (cy + largo * Math.sin(angulo));

        g2.drawLine(cx, cy, xFinal, yFinal);

        int anchoFlecha = 10;
        int largoFlecha = 20;

        int x1 = (int) (xFinal - anchoFlecha * Math.cos(angulo - Math.PI / 6));
        int y1 = (int) (yFinal - anchoFlecha * Math.sin(angulo - Math.PI / 6));

        int x2 = (int) (xFinal - anchoFlecha * Math.cos(angulo + Math.PI / 6));
        int y2 = (int) (yFinal - anchoFlecha * Math.sin(angulo + Math.PI / 6));

        Polygon flecha = new Polygon();
        flecha.addPoint(xFinal, yFinal);
        flecha.addPoint(x1, y1);
        flecha.addPoint(x2, y2);
        g2.fillPolygon(flecha);
    }

    private void dibujarManecillas(Graphics2D g2, int cx, int cy, int radio) {
        Calendar calendario = Calendar.getInstance();
        int hora = calendario.get(Calendar.HOUR);
        int minuto = calendario.get(Calendar.MINUTE);
        int segundo = calendario.get(Calendar.SECOND);

        // Dibujar la manecilla de las horas en forma de flecha
        dibujarManecillaConFlecha(g2, cx, cy, (hora % 12) * 30 + minuto / 2, radio - 100, 8, Color.BLUE);

        // Dibujar la manecilla de los minutos en forma de flecha
        dibujarManecillaConFlecha(g2, cx, cy, minuto * 6, radio - 60, 6, Color.GREEN);

        // Dibujar la manecilla de los segundos en forma de flecha
        dibujarManecillaConFlecha(g2, cx, cy, segundo * 6, radio - 40, 4, Color.RED);
    }

    private void dibujarManecilla(Graphics2D g2, int cx, int cy, double anguloGrados, int largo, int grosor, Color color) {
        double angulo = Math.toRadians(anguloGrados - 90); // Rotar 90 grados para el ángulo correcto

        // Configurar el grosor y color de la manecilla
        g2.setStroke(new BasicStroke(grosor));
        g2.setColor(color);

        // Dibujar la manecilla
        int x = (int) (cx + largo * Math.cos(angulo));
        int y = (int) (cy + largo * Math.sin(angulo));
        g2.drawLine(cx, cy, x, y);
    }

    @Override
    public void run() {
        while (true) {
            repaint();
            try {
                Thread.sleep(1000); // Actualizar cada segundo
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        JFrame ventana = new JFrame("Reloj Analógico");
        Practica05DiegoIvanSotoArreola reloj = new Practica05DiegoIvanSotoArreola();
        System.out.println("Directorio de trabajo actual: " + System.getProperty("user.dir"));
        ventana.add(reloj);
        ventana.pack();
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setVisible(true);

        // Iniciar el hilo del reloj
        Thread hiloReloj = new Thread(reloj);
        hiloReloj.start();
    }

}
